/*
 *  
 * (c) Pluf & Ripe / 7a69ezine.org 
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>

int main(int argc, char **argv, char **envp) 
{
	char *p1, *p2, *p3;
	int i;
	
	printf("[*] Testing stack context\n");
	printf("argc = %i\n", argc);
	printf("argv = %x\n", argv);
	for(i = 0 ; i < argc ; i++) {
		printf("argv[%i] = 0x%.8lx = ", i, argv[i]); fflush(stdout);
		printf("%s\n", argv[i]);
	}
	for (i = 0 ; envp[i] ; i++) {
		printf("envp[%i] = 0x%.8lx = ", i, envp[i]); fflush(stdout);
		printf("%s\n", envp[i]);
	}

	printf("\n[*] Testing heap\n");
	p1 = malloc(256);
	p2 = malloc(1024);
	memset(p1, 'A', 256);
	memset(p2, 'B', 1024);
	printf("p1 = 0x%.8x = ", p1); fflush(stdout);
	printf("%s\n", p1);
	printf("p2 = 0x%.8x = ", p2); fflush(stdout);
	printf("%s\n", p2);
	p3 = malloc(16);
	memcpy(p3, p2, 10);
	printf("p3 = 0x%.8x = ", p3); fflush(stdout);
	printf("%s\n", p3);
	free(p1);
	p1 = malloc(8184);
	strcpy(p1, "Testing, can you read this one?");
	printf("p1 = 0x%.8x = ", p1); fflush(stdout);
	printf("%s\n", p1);
	free(p2);
	p2 = malloc(4096);
	strcpy(p2, "Testing, can you read this one?");
	printf("p2 = 0x%.8x = ", p2); fflush(stdout);
	printf("%s\n", p2);

	printf("\n[*] Testing signals\n");
	printf("%x\n", signal(SIGQUIT, SIG_IGN));

	exit(0);

}
