/*
 *
 * (c) Pluf & Ripe / 7a69ezine.org
 *
 */

/* identify architecture */
#if defined(__i386__) || defined(i386)
#define ARCH_X86_32
#elif defined(__amd64__) || defined(__x86_64__)
#define ARCH_X86_64
#endif

/* identify system */
#if defined(__linux__)
#ifndef SYS_LINUX
#define SYS_LINUX
#endif
#elif defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
#ifndef SYS_BSD
#define SYS_BSD
#endif
#if defined(__FreeBSD__)
#define SYS_BSD_FREEBSD
#elif defined(__NetBSD__)
#define SYS_BSD_NETBSD
#elif defined(__OpenBSD__)
#define SYS_BSD_OPENBSD
#endif
#endif

#define PT_STACK        0x7a69

#if defined(ARCH_X86_32)
#define	PG_SIZE		0x1000
#define	LOADER		"loader_x86_32.S"
#if defined(SYS_LINUX)
#define	TOP_STACK	0xC0000000
#elif defined(SYS_BSD_FREEBSD)
#define TOP_STACK	0xBFC00000		
#elif defined(SYS_BSD_NETBSD)
#define	TOP_STACK	0xBFBF0000
#elif defined(SYS_BSD_OPENBSD)
#define TOP_STACK	0xCFBF0000
#endif

#elif defined(ARCH_X86_64)
#define PG_SIZE		0x10000
#define	LOADER		"loader_x86_64.S"
#if defined(SYS_LINUX)
#define TOP_STACK	0x800000000000
#endif
#endif

