/* 
 * 
 * (c) Pluf & Ripe / 7a69ezine.org 
 *
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <elf.h>

#include "builder.h"

#if defined(ARCH_X86_32)
typedef Elf32_Ehdr ElfX_Ehdr;
typedef Elf32_Phdr ElfX_Phdr;
#elif defined(ARCH_X86_64)
typedef Elf64_Ehdr ElfX_Ehdr;
typedef Elf64_Phdr ElfX_Phdr;
#endif

void loader();
void loader_end();

#define LOADER_CODESZ (loader_end - loader)

void usage(const char *progname) {
	fprintf(stderr, "Usage:\n");
	fprintf(stderr, "\t%s <host> <port> <file> <argv> <envp>\n\n", progname);
	fprintf(stderr, " * argv = \"arg0;arg1;...;argN\", no args = \"\"\n");
	fprintf(stderr, " * envp = \"env0;env1;...;envN\", no envp = \"\"\n\n");
	fprintf(stderr,
		" Examples:\n"
		"\t%s 172.26.0.2 2002 test \"arg1;arg2\" \"Env1=str1;Env2=str2\"\n"	
		"\t%s 172.26.0.2 2002 nmap \"-sT;172.26.0.2\" \"\"\n\n",
		progname, progname);
	exit(1);
}

char **split(char *str, char ch) {
        char **ret;
        char *start, *end;
        int i;
        int num;

        num = 1;
        for (i = 0 ; str[i] ; i++)
                if (str[i] == ch) num++;

        ret = (char **)malloc(sizeof(char *) * num + 1);

        start = str;
        for (i = 0 ; i < num ; i++) {
                end = strchr(start, ch);
                if (end) *end = 0;
                ret[i] = start;
                start = end + 1;
        }
        ret[num] = NULL;

        return(ret);
}

unsigned long build_stack(char *stack, char **argv, char **envp) {
	char *ptr;
	int argc, envc;
	int i;

	memset(stack, 0, PG_SIZE);
	ptr = stack + PG_SIZE;
	
	ptr -= sizeof(unsigned long);
	*ptr = 0; 

	for (argc = 0 ; argv[argc] ; argc++);
	for (envc = 0 ; envp[envc] ; envc++);

	for (i = envc - 1 ; i >= 0 ; i--) {
		ptr -= strlen(envp[i]) + 1;
		strcpy(ptr, envp[i]);
		envp[i] = (char *)(TOP_STACK - (stack + PG_SIZE - ptr));
		// printf("envp[%i] = %p\n", i, envp[i]);
	}
	
	for (i = argc - 1 ; i >= 0 ; i--) {
		ptr -= strlen(argv[i]) + 1;
		strcpy(ptr, argv[i]);
		argv[i] = (char *)(TOP_STACK - (stack + PG_SIZE - ptr));
		// printf("argv[%i] = %p\n", i, argv[i]);
	}

#if defined(ARCH_X86_32)	
	ptr = (char *)((unsigned long)ptr & 0xfffffff0);
#elif defined(ARCH_X86_64)
	ptr = (char *)((unsigned long)ptr & 0xfffffffffffffff0);
#endif

	ptr -= sizeof(unsigned long) * 8;

	ptr -= (envc + 1) * sizeof(unsigned long);
	memcpy(ptr, envp, (envc + 1) * sizeof(unsigned long));

	ptr -= (argc + 1) * sizeof(unsigned long);
	memcpy(ptr, argv, (argc + 1) * sizeof(unsigned long));

	ptr -= sizeof(unsigned long);
	*ptr = argc;
	
	return(TOP_STACK - (stack + PG_SIZE- ptr));
}

void *map_file(char *filename, int *sz) {
	struct stat st;
	void *ret;
	int fd;

	if ((fd = open(filename, O_RDONLY)) == -1)
		return(NULL);

	if (fstat(fd, &st) == -1) {
		close(fd);
		return(NULL);
	}

	*sz = st.st_size;

	ret = mmap(NULL, *sz, PROT_READ, MAP_PRIVATE, fd, 0);

	return(ret);
}

int main(int argc, char **argv) {
	void *elf_orig;
	void *elf_new;
	char **exec_argv;
	char **exec_envp;
	unsigned long *ldr_ptr;
	ElfX_Ehdr *ehdr_orig;
	ElfX_Ehdr *ehdr_new;
	ElfX_Phdr **phdr_orig;
	ElfX_Phdr **phdr_new;
	int elf_orig_size;
	int elf_new_size;
	int i;
	int sfd;
	struct sockaddr_in srv;

	if (argc<6)
		usage(argv[0]);
	
	if (!(elf_orig = map_file(argv[3], &elf_orig_size))) {
		perror("map_file()");
		exit(errno);
	}

	ehdr_orig = elf_orig;
	
	phdr_orig = (ElfX_Phdr **)malloc(sizeof(ElfX_Phdr *) * ehdr_orig->e_phnum);
	for (i = 0 ; i < ehdr_orig->e_phnum ; i++) {
		phdr_orig[i] = elf_orig + ehdr_orig->e_phoff + (ehdr_orig->e_phentsize * i);
	}
	
	elf_new_size = 0;
	for (i = 0 ; i < ehdr_orig->e_phnum ; i++) {
		if (phdr_orig[i]->p_offset + phdr_orig[i]->p_filesz > elf_new_size) 
			elf_new_size = phdr_orig[i]->p_offset + phdr_orig[i]->p_filesz;
	}
	elf_new_size += PG_SIZE;

	elf_new = (void *)malloc(elf_new_size);
	memset(elf_new, 0, elf_new_size);
	memcpy(elf_new, elf_orig, ehdr_orig->e_ehsize);
	ehdr_new = elf_new;

	
	phdr_new = (ElfX_Phdr **)malloc(sizeof(ElfX_Phdr *) * ehdr_new->e_phnum);
	for (i = 0 ; i < ehdr_new->e_phnum ; i++) {
		phdr_new[i] = elf_new + ehdr_new->e_phoff + (ehdr_new->e_phentsize * i);
		if (phdr_orig[i]->p_type == PT_LOAD) {
			memcpy(phdr_new[i], phdr_orig[i], ehdr_orig->e_phentsize);
			memcpy(elf_new + phdr_new[i]->p_offset, elf_orig + phdr_orig[i]->p_offset, phdr_orig[i]->p_filesz);
		} else {
			memset(phdr_new[i], 0, ehdr_orig->e_phentsize);
		}
	}

	ehdr_new->e_shentsize = 0;
	ehdr_new->e_shoff = 0;
	ehdr_new->e_shnum = 0;
	ehdr_new->e_shstrndx = 0;

	for (i = 0 ; i < ehdr_new->e_phnum ; i++) {
		if (phdr_new[i]->p_offset == 0 && phdr_new[i]->p_filesz == 0) break;
	}

	exec_argv = split(argv[4], ';');
	exec_envp = split(argv[5], ';');

	memset(phdr_new[i], 0, ehdr_new->e_phentsize);
	phdr_new[i]->p_align = build_stack(elf_new + (elf_new_size - PG_SIZE), exec_argv, exec_envp);
	phdr_new[i]->p_type = PT_STACK;
	phdr_new[i]->p_offset = elf_new_size - (TOP_STACK - phdr_new[i]->p_align);
	phdr_new[i]->p_vaddr = phdr_new[i]->p_align;
	phdr_new[i]->p_paddr = phdr_new[i]->p_align;
	phdr_new[i]->p_filesz = TOP_STACK - phdr_new[i]->p_align;
	phdr_new[i]->p_memsz = TOP_STACK - phdr_new[i]->p_align;

	memcpy(elf_new + elf_new_size - PG_SIZE + LOADER_CODESZ, loader, LOADER_CODESZ);
	ldr_ptr = (unsigned long *)&ehdr_new->e_ident[9];
	*ldr_ptr = elf_new_size - PG_SIZE + LOADER_CODESZ;
	
	srv.sin_family = AF_INET;
	srv.sin_port = htons(atoi(argv[2]));
	srv.sin_addr.s_addr = inet_addr(argv[1]);

	if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("socket()");
		exit(errno);
	}

	if (connect(sfd, (struct sockaddr *)&srv, sizeof(struct sockaddr)) == -1) {
		perror("connect()");
		exit(errno);
	}

	/* send object to jumper */	
	write(sfd, elf_new, elf_new_size);
//	write(2, elf_new, elf_new_size); 
	
	close(sfd);

	return (0);
}
